#-- import packages
import numpy as np
import pandas as pd
import datetime as dt

#-- Define a class including all parameters of the testing environment
class Para():
    path_data = "../Data/"
    path_result = '../Result/'
    index = "SH_Comp"
    fee = 0.00025 # 交易成本万分之2.5
    stop_pct = 0.05
    init_cash = 1 # 起始投资金额
para = Para()

df_index = pd.read_csv(para.path_data+"raw_"+para.index+".csv",dtype = {"high":np.float64, "low":np.float64, "close":np.float64})
df_index.columns = ["date", "high", "low", "close"]
df_index["date"] = pd.to_datetime(df_index["date"], format="%Y%m%d").dt.strftime("%Y-%m-%d") 

df_index.to_csv(para.path_data+para.index+".csv", index=False)