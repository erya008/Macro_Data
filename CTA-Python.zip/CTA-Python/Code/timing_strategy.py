#-- import packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#-- Define a class including all parameters of the testing environment
class Para():
    path_data = "../Data/"
    path_result = '../Result/'
    index = "SH_Comp"
    fee = 0.00025 # 交易成本万分之2.5
    stop_pct = 0.05
    init_cash = 1 # 起始投资金额
para = Para()

"""
Initialize values.
"""
def initialize(df_data):
    df_data["状态"] = 0
    df_data["股数"] = 0
    df_data["剩余现金"] = para.init_cash
    df_data["净值"] = para.init_cash
    return df_data


"""
Calculate Average true range for a given dataframe and 均线周期。
"""
def calc_atr(df_data, num_day):
    atr_data = df_data.copy()
    atr_data["tr"] = None
    for i in atr_data.index:
        if i == 0:
            atr_data.loc[i, "tr"] = atr_data.loc[i, "high"] - atr_data.loc[i, "low"]
        else:
            atr_data.loc[i, "tr"] = max(atr_data.loc[i, "high"] - atr_data.loc[i, "low"], 
                                        abs(atr_data.loc[i, "high"] - atr_data.loc[i-1, "close"]), 
                                        abs(atr_data.loc[i, "low"] - atr_data.loc[i-1, "close"]))
    atr_data["atr"] = atr_data['tr'].rolling(window=num_day, center=False).mean()
    # 保留三位小数
    atr_data["atr"] = atr_data["atr"].round(decimals=3)
    return atr_data

"""
Calculate MACD for a given dataframe and parameters。
"""
def get_macd(df_data, short_period, long_period, signal_period):
    macd_data = df_data.copy()
    ema_short = df_data['close'].ewm(span=short_period).mean() # 根据收盘价计算的短期指数移动平均线(EMA)
    ema_long = df_data['close'].ewm(span=long_period).mean() # 根据收盘价计算的长期指数移动平均线(EMA)
    dif = ema_short - ema_long # 离差值
    dea = dif.ewm(span=signal_period).mean()
    macd = dif - dea
    macd_data["dif"] = dif
    macd_data["macd"] = macd
    return macd_data

"""
Execution records.
"""
def closing(df_data, i, prev_position):
    df_data.loc[i, "状态"] = 0
    df_data.loc[i, "股数"] = 0
    df_data.loc[i, "剩余现金"] = df_data.loc[i-1, "剩余现金"] + df_data.loc[i-1, "股数"]*df_data.loc[i, "close"]*(1-para.fee*prev_position)
    df_data.loc[i, "净值"] = df_data.loc[i, "剩余现金"]
    return df_data

def long(df_data, i):
    buy_num = df_data.loc[i-1, "剩余现金"] / df_data.loc[i, "close"]
    df_data.loc[i, "状态"] = 1
    df_data.loc[i, "股数"] = df_data.loc[i-1, "股数"] + buy_num
    df_data.loc[i, "剩余现金"] = -df_data.loc[i-1, "剩余现金"]*para.fee
    df_data.loc[i, "净值"] = df_data.loc[i, "股数"] * df_data.loc[i, "close"] + df_data.loc[i, "剩余现金"]
    return df_data

def shorting(df_data, i):
    sell_num = df_data.loc[i-1, "剩余现金"] / df_data.loc[i, "close"]
    df_data.loc[i, "状态"] = -1
    df_data.loc[i, "股数"] = df_data.loc[i-1, "股数"] - sell_num
    df_data.loc[i, "剩余现金"] = df_data.loc[i-1, "剩余现金"] * (2-para.fee)
    df_data.loc[i, "净值"] = df_data.loc[i, "股数"] * df_data.loc[i, "close"] + df_data.loc[i, "剩余现金"]
    return df_data

def hold(df_data, i):
    df_data.loc[i, "状态"] = df_data.loc[i-1, "状态"]
    df_data.loc[i, "股数"] = df_data.loc[i-1, "股数"]
    df_data.loc[i, "剩余现金"] = df_data.loc[i-1, "剩余现金"]
    df_data.loc[i, "净值"] = df_data.loc[i, "股数"] * df_data.loc[i, "close"] + df_data.loc[i, "剩余现金"]   
    return df_data


"""
Basic strategies.
"""
def strategy(df_data, strat_type, num_day = 5, bandwidth = 0.01, short = True):
    temp_data = df_data.copy()
    
    temp_data["ma_"+str(num_day)] = temp_data['close'].rolling(window=num_day, center=False).mean()
    # 保留三位小数
    temp_data['close'] = temp_data['close'].round(decimals=3)
    temp_data["ma_"+str(num_day)] = temp_data["ma_"+str(num_day)].round(decimals=3)
    
    # 均线策略
    if strat_type == "ma":
        tempStr = "ma_"+str(num_day)
    # 布林线策略
    elif strat_type == "boll":
        temp_data["std_"+str(num_day)] = temp_data['close'].rolling(window=num_day, center=False).std()
        temp_data["std_"+str(num_day)] = temp_data["std_"+str(num_day)].round(decimals=3)
        tempStr = "std_"+str(num_day)
    # ATR通道策略
    elif strat_type == "atr":
        temp_data = calc_atr(temp_data, num_day)
        tempStr = "atr"
    
    # Initialize
    temp_data = initialize(temp_data)

    print("Start strategy:", strat_type)

    for i in range(num_day, temp_data.shape[0]):

        # 上笔交易亏损1%，平仓
        if (i >= 2) and (1 - temp_data.loc[i-1, "净值"]/temp_data.loc[i-2, "净值"] > para.stop_pct):
            temp_data = closing(temp_data, i, temp_data.loc[i-1, "状态"])
        # 多头平仓
        elif (temp_data.loc[i-1, "状态"] == 1) and (temp_data.loc[i-1, "close"] <= temp_data.loc[i-1, "ma_"+str(num_day)]):
            temp_data = closing(temp_data, i, 1)
        # 空头平仓
        elif (temp_data.loc[i-1, "状态"] == -1) and (temp_data.loc[i-1, "close"] >= temp_data.loc[i-1, "ma_"+str(num_day)]):
            assert short == True, "Cannot short."
            temp_data = closing(temp_data, i, -1)
        # 上涨信号，今日全仓买入
        elif (temp_data.loc[i-1, "状态"] == 0) and (temp_data.loc[i-1, "close"] > (temp_data.loc[i-1, "ma_"+str(num_day)] 
               	                                                             + bandwidth * temp_data.loc[i-1, tempStr])):
            temp_data = long(temp_data, i)
        # 下跌信号，今日全仓卖空
        elif short == True and temp_data.loc[i-1, "状态"] == 0 and (temp_data.loc[i-1, "close"] < (temp_data.loc[i-1, "ma_"+str(num_day)] - bandwidth * temp_data.loc[i-1, tempStr])):
            temp_data = shorting(temp_data, i)
        # 持仓/空仓
        else:
            temp_data = hold(temp_data, i)
    return temp_data


def strategy_macd(df_data, short_period=12, long_period=26, signal_period=9, short = True):
    temp_data = get_macd(df_data, short_period, long_period, signal_period)
    # 保留三位小数
    temp_data['close'] = temp_data['close'].round(decimals=3)
    temp_data['dif'] = temp_data['dif'].round(decimals=3)
    temp_data['macd'] = temp_data['macd'].round(decimals=3)
    
    # Initialize
    temp_data = initialize(temp_data)

    print("Start strategy: MACD")
    for i in range(1, temp_data.shape[0]):       
        # 上笔交易亏损1%，平仓
        if (i >= 2) and (1 - temp_data.loc[i-1, "净值"]/temp_data.loc[i-2, "净值"] > para.stop_pct):
            temp_data = closing(temp_data, i, temp_data.loc[i-1, "状态"])
        # 多头平仓
        elif (temp_data.loc[i-1, "状态"] == 1) and (temp_data.loc[i-1, "dif"] < 0):
        	temp_data = closing(temp_data, i, 1)
        # 空头平仓
        elif (temp_data.loc[i-1, "状态"] == -1) and (temp_data.loc[i-1, "dif"] > 0):
            assert short == True, "Cannot short."
            temp_data = closing(temp_data, i, -1)
        # 上涨信号，今日全仓买入
        elif (temp_data.loc[i-1, "状态"] == 0) and (temp_data.loc[i-1, "dif"] > 0) and (temp_data.loc[i-1, "macd"] > 0):
            temp_data = long(temp_data, i)
        # 下跌信号，今日全仓卖空
        elif short == True and (temp_data.loc[i-1, "状态"] == 0) and (temp_data.loc[i-1, "dif"] < 0) and (temp_data.loc[i-1, "macd"] < 0):
            temp_data = shorting(temp_data, i)
        # 持仓/空仓
        else:
            temp_data = hold(temp_data, i)
    return temp_data


def strategy_double_ma(df_data, short_period=10, long_period=20, short = True):
    temp_data = df_data.copy()
    
    temp_data["ma_"+str(short_period)] = temp_data['close'].rolling(window=short_period, center=False).mean()
    temp_data["ma_"+str(long_period)] = temp_data['close'].rolling(window=long_period, center=False).mean()
    # 保留三位小数
    temp_data['close'] = temp_data['close'].round(decimals=3)
    temp_data["ma_"+str(short_period)] = temp_data["ma_"+str(short_period)].round(decimals=3)
    temp_data["ma_"+str(long_period)] = temp_data["ma_"+str(long_period)].round(decimals=3)
    
    # Initialize
    temp_data = initialize(temp_data)
    
    for i in range(long_period-1, temp_data.shape[0]):
        # 若短线 > 长线：信号 = 1
        if temp_data.loc[i,'ma_'+str(short_period)] > 1.02*temp_data.loc[i,'ma_'+str(long_period)]:
            temp_data.loc[i,'信号'] = 1
        else:
            temp_data.loc[i,'信号'] = 0

    print("Start strategy: 双均线")
    for i in range(long_period+1, temp_data.shape[0]):
       
        # 上笔交易亏损1%，平仓
        if (i >= 2) and (1 - temp_data.loc[i-1, "净值"]/temp_data.loc[i-2, "净值"] > para.stop_pct):
            temp_data = closing(temp_data, i, temp_data.loc[i-1, "状态"])

        # 死叉信号
        elif temp_data.loc[i-2,'信号'] == 1 and temp_data.loc[i-1,'信号'] == 0:
            # 先多头平仓
            temp_data = closing(temp_data, i, 1)
            # 再做空
            if short == True:
                sell_num = temp_data.loc[i, "剩余现金"] / temp_data.loc[i, "close"]
                temp_data.loc[i, "状态"] = -1
                temp_data.loc[i, "股数"] = - sell_num
                temp_data.loc[i, "剩余现金"] = temp_data.loc[i, "剩余现金"] * (2-para.fee)
                temp_data.loc[i, "净值"] = temp_data.loc[i, "股数"] * temp_data.loc[i, "close"] + temp_data.loc[i, "剩余现金"]

        # 金叉信号
        elif temp_data.loc[i-2,'信号'] == 0 and temp_data.loc[i-1,'信号'] == 1:
            # 先空头平仓
            if short == True:
                temp_data.loc[i, "剩余现金"] = temp_data.loc[i-1, "剩余现金"] - (-temp_data.loc[i-1, "股数"])*temp_data.loc[i, "close"]*(1+para.fee)
            else:
                temp_data.loc[i, "剩余现金"] = temp_data.loc[i-1, "剩余现金"]
            # 再做多
            buy_num = temp_data.loc[i, "剩余现金"] / temp_data.loc[i, "close"]
            temp_data.loc[i, "状态"] = 1
            temp_data.loc[i, "股数"] = buy_num
            temp_data.loc[i, "剩余现金"] = -temp_data.loc[i, "剩余现金"]*para.fee
            temp_data.loc[i, "净值"] = temp_data.loc[i, "股数"] * temp_data.loc[i, "close"] + temp_data.loc[i, "剩余现金"]

        # 持仓/空仓
        else:
            temp_data = hold(temp_data, i)
    return temp_data

"""
Shorting is allowed 趋势测试及评估
"""
data = pd.read_csv(para.path_data+para.index+".csv")
data = data[~data["close"].isnull()].reset_index(drop = True) # 去掉NaN值

df_result = pd.DataFrame()
df_result["date"] = data["date"]
df_result["BASELINE"] = list(para.init_cash/data["close"].iloc[0]*data["close"])
print("可做空")
df_strategy_ma = strategy(data, strat_type="ma", num_day = 40, bandwidth = 0.01)
df_strategy_boll = strategy(data, strat_type="boll", num_day = 40, bandwidth = 0.01)
df_strategy_atr = strategy(data, strat_type="atr", num_day = 40, bandwidth = 0.01)
df_strategy_macd = strategy_macd(data, short_period = 4, long_period = 40, signal_period = 9)
df_strategy_double_ma = strategy_double_ma(data, short_period=20, long_period=120)

df_result["MA"] = list(df_strategy_ma["净值"])
df_result["BOLL"] = list(df_strategy_boll["净值"])
df_result["ATR"] = list(df_strategy_atr["净值"])
df_result["MACD"] = list(df_strategy_macd["净值"])
df_result["DOUBLE_MA"] = list(df_strategy_double_ma["净值"])

# 评价指标
print("Evaluating 可做空趋势策略")
df_eval = pd.DataFrame(np.nan, columns=["BASELINE", "MA", "BOLL", "ATR", "MACD", "DOUBLE_MA"], 
                       index=["年化收益率","年化波动率","夏普比率","最大回撤","CALMAR比率"])
def calc_drawdown(row, strategy):
    return row[strategy]/df_result.loc[0:row.name+1, strategy].max()-1
for i in ["BASELINE", "MA", "DOUBLE_MA", "BOLL", "ATR", "MACD"]: 
    if i == "BASELINE":
        n = 0
    elif i == "MACD":
    	n = 1
    else:
        n = 39
    df_eval.loc["年化收益率", i] = np.power(df_result[i].iloc[-1],250/(df_result[i].shape[0]-n)) - 1
    df_eval.loc["年化波动率", i] = (df_result[i] / df_result[i].shift(1) - 1).std(ddof=1) * np.sqrt(250)
    df_eval.loc["夏普比率", i] = df_eval.loc["年化收益率", i]/df_eval.loc["年化波动率", i]
    df_eval.loc["最大回撤", i] = -df_result.apply(lambda x: calc_drawdown(x, i), axis=1).min()
    df_eval.loc["CALMAR比率", i] = df_eval.loc["年化收益率", i]/df_eval.loc["最大回撤", i]
df_eval.to_excel(para.path_result+para.index+"_eval可做空.xlsx")


"""
Shorting is not allowed 趋势测试及评估
"""
df_result = pd.DataFrame()
df_result["date"] = data["date"]
df_result["BASELINE"] = list(para.init_cash/data["close"].iloc[0]*data["close"])
print("不可做空")
df_strategy_ma = strategy(data, strat_type="ma", num_day = 40, bandwidth = 0.01, short = False)
df_strategy_boll = strategy(data, strat_type="boll", num_day = 40, bandwidth = 0.01, short = False)
df_strategy_atr = strategy(data, strat_type="atr", num_day = 40, bandwidth = 0.01, short = False)
df_strategy_macd = strategy_macd(data, short_period = 4, long_period = 40, signal_period = 9, short = False)
df_strategy_double_ma = strategy_double_ma(data, short_period=4, long_period=40, short = False)

df_result["MA"] = list(df_strategy_ma["净值"])
df_result["BOLL"] = list(df_strategy_boll["净值"])
df_result["ATR"] = list(df_strategy_atr["净值"])
df_result["MACD"] = list(df_strategy_macd["净值"])
df_result["DOUBLE_MA"] = list(df_strategy_double_ma["净值"])

# 评价指标
print("Evaluating 不可做空趋势策略")
df_eval = pd.DataFrame(np.nan, columns=["BASELINE", "MA", "BOLL", "ATR", "MACD", "DOUBLE_MA"], 
                       index=["年化收益率","年化波动率","夏普比率","最大回撤","CALMAR比率"])

for i in ["BASELINE", "MA", "DOUBLE_MA", "BOLL", "ATR", "MACD"]:
    if i == "BASELINE":
        n = 0
    elif i == "MACD":
        n = 1
    else:
        n = 39
    df_eval.loc["年化收益率", i] = np.power(df_result[i].iloc[-1],250/(df_result[i].shape[0]-n)) - 1
    df_eval.loc["年化波动率", i] = (df_result[i] / df_result[i].shift(1) - 1).std(ddof=1) * np.sqrt(250)
    df_eval.loc["夏普比率", i] = df_eval.loc["年化收益率", i]/df_eval.loc["年化波动率", i]
    df_eval.loc["最大回撤", i] = -df_result.apply(lambda x: calc_drawdown(x, i), axis=1).min()
    df_eval.loc["CALMAR比率", i] = df_eval.loc["年化收益率", i]/df_eval.loc["最大回撤", i]
        
df_eval.to_excel(para.path_result+para.index+"_eval不可做空.xlsx")
